/*
 ADOBE CONFIDENTIAL
 
 Copyright 2019 Adobe
 All Rights Reserved.
 
 NOTICE: Adobe permits you to use, modify, and distribute this file in
 accordance with the terms of the Adobe license agreement accompanying
 it. If you have received this file from a source other than Adobe,
 then your use, modification, or distribution of it requires the prior
 written permission of Adobe.
 */

#import "QuestionSet.h"
#import "TriviaQuestion.h"

@interface QuestionSet()

@property (nonatomic, strong) NSString* title;
@property (nonatomic, strong) NSMutableArray<TriviaQuestion*>* questions;

@end

@implementation QuestionSet

- (instancetype) initWithSerializedRepresentation: (NSDictionary*) serializedRepresentation {
    self = [super init];
    
    if (!self) {
        return nil;
    }
    
    if (![serializedRepresentation isKindOfClass:NSDictionary.class]) {
        NSLog(@"TRIVIA LOG - Incorrect question set format - %@", NSStringFromClass(serializedRepresentation.class));
        return nil;
    }
    
    NSString *titleText = serializedRepresentation[@"title"];
    NSArray *questionsArray = serializedRepresentation[@"questions"];
    
    if (![titleText isKindOfClass:NSString.class] || titleText.length == 0) {
        NSLog(@"TRIVIA LOG - Incorrect question set format, title was blank or not a string.");
        return nil;
    }
    
    if(![questionsArray isKindOfClass: NSArray.class] || questionsArray.count == 0) {
        NSLog(@"TRIVIA LOG - Incorrect answer 1 format, question was blank or incorrect type.");
        return nil;
    }
    
    _questions = [[NSMutableArray alloc] init];
    for (NSDictionary* questionDict in questionsArray) {
        TriviaQuestion* question = [[TriviaQuestion alloc] initWithSerializedRepresentation: questionDict];
        if (question) {
            [_questions addObject: question];
        }
    }
    
    if (!_questions.count) {
        NSLog(@"TRIVIA LOG - Unable to find questions for set.");
        return nil;
    }
    
    _title = titleText;
    return self;
}

- (NSString*) title {
    return _title;
}

- (NSArray<TriviaQuestion*>*) questions {
    return _questions;
}

@end
