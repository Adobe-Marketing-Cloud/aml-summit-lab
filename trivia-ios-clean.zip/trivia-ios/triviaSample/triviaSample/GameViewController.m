/*
 ADOBE CONFIDENTIAL
 
 Copyright 2019 Adobe
 All Rights Reserved.
 
 NOTICE: Adobe permits you to use, modify, and distribute this file in
 accordance with the terms of the Adobe license agreement accompanying
 it. If you have received this file from a source other than Adobe,
 then your use, modification, or distribution of it requires the prior
 written permission of Adobe.
 */

#import "GameViewController.h"
#import "TriviaQuestion.h"
#import "QuestionSet.h"
#import "GameResult.h"
#import "ViewController.h"

#define kQUESTIONS_IN_GAME 10

@interface GameViewController ()

@property (nonatomic, strong) IBOutlet UILabel* statsLabel;
@property (nonatomic, strong) IBOutlet UILabel* questionLabel;
@property (nonatomic, strong) IBOutlet UIButton* answerButton1;
@property (nonatomic, strong) IBOutlet UIButton* answerButton2;
@property (nonatomic, strong) IBOutlet UIButton* answerButton3;
@property (nonatomic, strong) IBOutlet UIButton* answerButton4;

@property (nonatomic, strong) IBOutlet UIView* loadingView;
@property (nonatomic, strong) IBOutlet UIActivityIndicatorView *loadingIndicator;

@property (nonatomic, strong) IBOutlet UIView* scoreView;
@property (nonatomic, strong) IBOutlet UILabel* scorePercentage;

@property (nonatomic, strong) QuestionSet* questionSet;
@property (nonatomic, assign) NSUInteger currentQuestionIndex;
@property (nonatomic, assign) NSUInteger correctCount;
@property (nonatomic, assign) NSUInteger questionsAnswered;

@end

@implementation GameViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _currentQuestionIndex = 0;
    _correctCount = 0;
    _questionsAnswered = 0;
    
    _loadingView.layer.cornerRadius = 20.0f;
    _loadingView.layer.masksToBounds = YES;
    _scoreView.layer.cornerRadius = 20.0f;
    _scoreView.layer.masksToBounds = YES;
    [self showLoading];
}

- (void)viewDidAppear:(BOOL)animated {
    [self loadQuestionsFromURL];
}

- (void)showLoading {
    _questionLabel.hidden = YES;
    _answerButton1.hidden = YES;
    _answerButton2.hidden = YES;
    _answerButton3.hidden = YES;
    _answerButton4.hidden = YES;
    _statsLabel.hidden = YES;
    _scoreView.hidden = YES;
    
    [_loadingIndicator startAnimating];
    _loadingView.hidden = NO;
}

- (void)showScore {
    [_loadingIndicator stopAnimating];
    _loadingView.hidden = YES;
    _questionLabel.hidden = YES;
    _answerButton1.hidden = YES;
    _answerButton2.hidden = YES;
    _answerButton3.hidden = YES;
    _answerButton4.hidden = YES;
    _statsLabel.hidden = YES;
    
    _scoreView.hidden = NO;
}

- (void)showGame {
    [_loadingIndicator stopAnimating];
    _loadingView.hidden = YES;
    _scoreView.hidden = YES;

    _questionLabel.hidden = NO;
    _answerButton1.hidden = NO;
    _answerButton2.hidden = NO;
    _answerButton3.hidden = NO;
    _answerButton4.hidden = NO;
    _statsLabel.hidden = NO;
}

- (void)hydrate {
    TriviaQuestion* question = _questionSet.questions[_currentQuestionIndex];
    
    [_questionLabel setText: question.question];
    [_answerButton1 setTitle:question.answer1 forState:UIControlStateNormal];
    [_answerButton2 setTitle:question.answer2 forState:UIControlStateNormal];
    [_answerButton3 setTitle:question.answer3 forState:UIControlStateNormal];
    [_answerButton4 setTitle:question.answer4 forState:UIControlStateNormal];
    [_statsLabel setText:[NSString stringWithFormat:@"Questions Answered: %lu / %lu", _questionsAnswered, _questionSet.questions.count]];
}

- (void)loadAllQuestions {
    NSLog(@"game url is: %@", _gameURL);
    // load game from provided url.
    NSString *questionsFilePath = [[NSBundle mainBundle] pathForResource:@"questions" ofType:@"json"];
    NSData *questionData = [NSData dataWithContentsOfFile: questionsFilePath];
    NSError *jsonError;
    NSDictionary* questionsDict = [NSJSONSerialization JSONObjectWithData:questionData options:0 error:&jsonError];
    if (questionsDict == nil || ![questionsDict isKindOfClass:NSDictionary.class]) {
        NSLog(@"TRIVIA LOG - Unable to deserialize trivia questions file %@", jsonError.localizedDescription);
    }
    
    _questionSet = [[QuestionSet alloc] initWithSerializedRepresentation: questionsDict];
    
    [self hydrate];
    [self performSelector:@selector(showGame) withObject:nil afterDelay:1.0f];
}

- (void)finishGame {
    float gamePercentage = ((float)_correctCount / (float)_questionSet.questions.count) * 100;
    _scorePercentage.text = [NSString stringWithFormat:@"%d%%", (int)gamePercentage];
    [self showScore];
}

- (IBAction)quitbutton:(id)sender {
    [self dismissViewControllerAnimated:YES
                             completion:^{
                                 
                             }];
}

- (IBAction)answerButton:(id)sender {
    int correctAnswer = _questionSet.questions[_currentQuestionIndex].correctAnswer;
    if (sender == _answerButton1 && correctAnswer == 1) {
        ++_correctCount;
    } else if (sender == _answerButton2 && correctAnswer == 2) {
        ++_correctCount;
    } else if (sender == _answerButton3 && correctAnswer == 3) {
        ++_correctCount;
    } else if (sender == _answerButton4 && correctAnswer == 4) {
        ++_correctCount;
    }
    ++_questionsAnswered;
    if (++_currentQuestionIndex == _questionSet.questions.count) {
        // end game
        [self finishGame];
    } else {
        [self hydrate];
    }
}

- (GameResult*) result {
    GameResult* result = [[GameResult alloc] init];
    result.totalQuestions = kQUESTIONS_IN_GAME;
    result.correctQuestions = _correctCount;
    
    return result;
}

- (void) loadQuestionsFromURL {
    NSLog(@"TRIVIA LOG - Retrieving game data from %@", _gameURL);
    NSURLSession* session = [NSURLSession sessionWithConfiguration:[NSURLSessionConfiguration ephemeralSessionConfiguration]];
    [[session dataTaskWithURL:_gameURL completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        if (error) {
            NSLog(@"TRIVIA LOG - Error downloading game data: %@", error.localizedDescription);
            [self quitbutton:self];
            return;
        }
        
        NSError *jsonError;
        NSDictionary* questionsDict = [NSJSONSerialization JSONObjectWithData:data options:0 error:&jsonError];
        if (questionsDict == nil || ![questionsDict isKindOfClass:NSDictionary.class]) {
            NSLog(@"TRIVIA LOG - Unable to deserialize trivia questions file %@", jsonError.localizedDescription);
        }
        
        dispatch_async(dispatch_get_main_queue(), ^{
            [self setQuestionSet: [[QuestionSet alloc] initWithSerializedRepresentation: questionsDict]];
            [self hydrate];
            [self showGame];
        });
    }] resume];
}
@end
