/*
 ADOBE CONFIDENTIAL
 
 Copyright 2019 Adobe
 All Rights Reserved.
 
 NOTICE: Adobe permits you to use, modify, and distribute this file in
 accordance with the terms of the Adobe license agreement accompanying
 it. If you have received this file from a source other than Adobe,
 then your use, modification, or distribution of it requires the prior
 written permission of Adobe.
 */

#import "TriviaQuestion.h"

@implementation TriviaQuestion

- (instancetype) initWithSerializedRepresentation: (nonnull NSDictionary*)serializedRepresentation {
    self = [super init];
    
    if (![serializedRepresentation isKindOfClass:NSDictionary.class]) {
        NSLog(@"TRIVIA LOG - Incorrect question format - %@", NSStringFromClass(serializedRepresentation.class));
        return nil;
    }
    
    NSString *questionText = serializedRepresentation[@"question"];
    NSString *answer1Text = serializedRepresentation[@"an1"];
    NSString *answer2Text = serializedRepresentation[@"an2"];
    NSString *answer3Text = serializedRepresentation[@"an3"];
    NSString *answer4Text = serializedRepresentation[@"an4"];
    NSNumber *correctAnswerNumber = serializedRepresentation[@"correct"];
    
    if (![questionText isKindOfClass:NSString.class] || questionText.length == 0) {
        NSLog(@"TRIVIA LOG - Incorrect question format, question was blank or incorrect type.");
        return nil;
    }
    if (![answer1Text isKindOfClass:NSString.class] || answer1Text.length == 0) {
        NSLog(@"TRIVIA LOG - Incorrect answer 1 format, question was blank or incorrect type.");
        return nil;
    }
    if (![answer2Text isKindOfClass:NSString.class] || answer2Text.length == 0) {
        NSLog(@"TRIVIA LOG - Incorrect answer 2 format, question was blank or incorrect type.");
        return nil;
    }
    if (![answer3Text isKindOfClass:NSString.class] || answer3Text.length == 0) {
        NSLog(@"TRIVIA LOG - Incorrect answer 3 format, question was blank or incorrect type.");
        return nil;
    }
    if (![answer4Text isKindOfClass:NSString.class] || answer4Text.length == 0) {
        NSLog(@"TRIVIA LOG - Incorrect answer 4 format, question was blank or incorrect type.");
        return nil;
    }
    if (![correctAnswerNumber isKindOfClass:NSNumber.class] || correctAnswerNumber.intValue < 1 || correctAnswerNumber.intValue > 4) {
        NSLog(@"TRIVIA LOG - Incorrect answer number format, must be an integer between 1 and 4.");
        return nil;
    }
    
    if (self) {
        _question = questionText;
        _answer1 = answer1Text;
        _answer2 = answer2Text;
        _answer3 = answer3Text;
        _answer4 = answer4Text;
        _correctAnswer = [correctAnswerNumber intValue];
    }
    
    return self;
}

- (BOOL) checkAnswer: (int) index {
    return _correctAnswer == index;
}

@end
