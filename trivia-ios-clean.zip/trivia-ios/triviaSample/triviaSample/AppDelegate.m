/*
 ADOBE CONFIDENTIAL
 
 Copyright 2019 Adobe
 All Rights Reserved.
 
 NOTICE: Adobe permits you to use, modify, and distribute this file in
 accordance with the terms of the Adobe license agreement accompanying
 it. If you have received this file from a source other than Adobe,
 then your use, modification, or distribution of it requires the prior
 written permission of Adobe.
 */

#import <UserNotifications/UserNotifications.h>
#import "AppDelegate.h"
#import "ACPPlacesMonitor.h"
#import "GameViewController.h"
#import "ViewController.h"

/*
 * Code Snippet #1
 *   >> Add import statements to AppDelegate.m
 */

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    /*
     * Code Snippet #2
     *   >> Enable logging and configure the app for our Property/Environment combination
     */
    
    
    
    /*
     * Code Snippet #3
     *   >> Register the necessary extensions for the SDK and start SDK processing
     */
    
    
    return YES;
}





- (BOOL)application:(UIApplication *)app openURL:(NSURL *)url options:(NSDictionary<UIApplicationOpenURLOptionsKey,id> *)options {
    if ([url.scheme isEqualToString:@"com.adobe.quizzer"] && [url.host isEqualToString:@"adobequiz"]) {
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Welcome to Adobe Summit" message:@"Thank you for joining us at Sands Expo and Convention center.  Would you like to take the Adobe Quiz?" preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *yesButton = [UIAlertAction actionWithTitle:@"Yes!" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            ViewController *menuVC = (ViewController *)self.window.rootViewController;
            [menuVC setGameUrl:[NSURL URLWithString:@"https://trivia-app-demo.s3.amazonaws.com/questionsets/adobe.json"]];
            [menuVC performSegueWithIdentifier:@"gameSegue" sender:@"deeplink"];
        }];
        UIAlertAction *noButton = [UIAlertAction actionWithTitle:@"No thanks" style:UIAlertActionStyleDefault handler:nil];
        [alert addAction:yesButton];
        [alert addAction:noButton];
        
        [self.window.rootViewController presentViewController:alert animated:YES completion:nil];
        
        return YES;
    }
    
    return NO;
}

@end
