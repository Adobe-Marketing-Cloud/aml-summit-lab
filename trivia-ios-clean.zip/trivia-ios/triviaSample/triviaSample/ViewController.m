/*
 ADOBE CONFIDENTIAL
 
 Copyright 2019 Adobe
 All Rights Reserved.
 
 NOTICE: Adobe permits you to use, modify, and distribute this file in
 accordance with the terms of the Adobe license agreement accompanying
 it. If you have received this file from a source other than Adobe,
 then your use, modification, or distribution of it requires the prior
 written permission of Adobe.
 */

#import "ViewController.h"
#import "GameResult.h"
#import "GameViewController.h"
#import "ACPPlacesMonitor.h"

@interface ViewController ()

@property (nonatomic, strong) IBOutlet UIButton* gameButton;
@property (nonatomic, strong) IBOutlet UIButton* settingsButton;
@property (nonatomic, strong) IBOutlet UIButton* disclaimerButton;

@property (nonatomic, strong) IBOutlet UIView* loadingView;
@property (nonatomic, strong) IBOutlet UIActivityIndicatorView *loadingIndicator;

@property (nonatomic, strong) NSURL* gameURL;
@property (nonatomic, strong) GameResult* gameResult;

@property (nonatomic, strong) IBOutlet UILabel* titleLabel;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _gameButton.titleLabel.numberOfLines = 1;
    _gameButton.titleLabel.adjustsFontSizeToFitWidth = YES;
    
    _settingsButton.titleLabel.numberOfLines = 1;
    _settingsButton.titleLabel.adjustsFontSizeToFitWidth = YES;
    
    _loadingView.layer.cornerRadius = 20.0f;
    _loadingView.layer.masksToBounds = YES;
    
    [self hideLoading];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        [ACPPlacesMonitor setLoggingEnabled:YES];
        [ACPPlacesMonitor registerExtension];
        [ACPPlacesMonitor startWithContinuousMonitoring:YES];
    });    
}

- (void)hideLoading {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.loadingIndicator stopAnimating];
        self.loadingView.hidden = YES;
    });
}

- (void)showLoading {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.loadingIndicator startAnimating];
        self.loadingView.hidden = NO;
    });
}

- (IBAction)gameButton:(id)sender {
    [self updateManifest];
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString: @"gameSegue"]) {
        GameViewController* gvc = [segue destinationViewController];
        [gvc setGameURL: _gameURL];
    }
}

// updates manifest for trivia games via remote download
- (void) updateManifest {
    // download manifest file from https://s3-us-west-2.amazonaws.com/trivia-app-demo/manifest.json
    NSURLSession *session = [NSURLSession sessionWithConfiguration:NSURLSessionConfiguration.ephemeralSessionConfiguration];
    NSURLRequest* request = [NSURLRequest requestWithURL:[NSURL URLWithString: @"https://s3-us-west-2.amazonaws.com/trivia-app-demo/manifest.json"]
                                             cachePolicy:NSURLRequestReloadIgnoringCacheData
                                         timeoutInterval:15.0f];
    
    NSURLSessionDataTask* task = [session dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        [self hideLoading];
        if (error != nil) {
            [self displayErrorMessage:[NSString stringWithFormat: @"Error downloading trivia manifest: %@", error.localizedDescription]];
            return;
        }
        NSError* jsonError = nil;
        NSDictionary* manifestDict = [NSJSONSerialization JSONObjectWithData:data options:0 error:&jsonError];
        if (manifestDict == nil || ![manifestDict isKindOfClass: NSDictionary.class]) {
            [self displayErrorMessage:[NSString stringWithFormat: @"Unable to parse manifest json: %@", jsonError.localizedDescription]];
            return;
        }
        
        NSArray* sets = manifestDict[@"sets"];
        if (![sets isKindOfClass: NSArray.class] || !sets.count) {
            [self displayErrorMessage:@"Trivia manifest was blank or malformed."];
            return;
        }
        
        // build actions for each game
        UIAlertController* alert = [UIAlertController alertControllerWithTitle:nil message:nil preferredStyle:UIAlertControllerStyleActionSheet];
        for(NSDictionary* questionSet in sets) {
            UIAlertAction* action = [UIAlertAction actionWithTitle:questionSet[@"title"] style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                self.gameURL = [NSURL URLWithString:questionSet[@"url"]];
                [self performSegueWithIdentifier:@"gameSegue" sender:self];
            }];
            [alert addAction: action];
        }
        
        [alert addAction: [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
           // do nothing.
        }]];
        
        dispatch_async(dispatch_get_main_queue(), ^{
            [self presentViewController:alert animated:YES completion:^{}];
        });
    }];
    [self showLoading];
    [task resume];
}

- (void) displayErrorMessage: (NSString*) message {
    UIAlertController* alert = [UIAlertController alertControllerWithTitle: @"Error" message:message preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction: [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
    }]];
    
    dispatch_async(dispatch_get_main_queue(), ^{
        [self presentViewController:alert animated:YES completion:^{}];
    });
}

- (void) setGameUrl:(NSURL *)gameUrl {
    _gameURL = gameUrl;
}

@end
